﻿using AutoMapper;
using crud_dotnet_api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace crud_dotnet_api.Services
{
    public class EmployeeService
    {
        private readonly AppDbContext _appDbContext;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;


        public EmployeeService(AppDbContext appDbContext, IConfiguration configuration, IMapper mapper, IWebHostEnvironment environment)
        {
            _appDbContext = appDbContext;
            _configuration = configuration;
            _mapper = mapper;
            _environment = environment;
        }



        //Log In
        public async Task<Employee> GetPersonByIdAndName(string name, string password)
        {
            var user = await _appDbContext.Employees.SingleOrDefaultAsync(x => x.Name == name && x.Password == password);
            if (user == null)
                return null;

            // Authentication successful
            return user;
        }
        private string GenerateJwtToken(Employee employee)
        {
            var claims = new[]
            {
      new Claim(JwtRegisteredClaimNames.Sub, employee.GuidId.ToString()),
      new Claim(JwtRegisteredClaimNames.Name, employee.Name),
      new Claim(ClaimTypes.Role, "admin")
  };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AppSettings:Token"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
          issuer: null,
          audience: null,
          claims: claims,
          expires: DateTime.Now.AddMinutes(30),
          signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        //Getting Data

        public async Task<List<Employee>> GetEmployeesAsync()
        {
            return await _appDbContext.Employees
                                       .Include(e => e.Qualifications)
                                       .ToListAsync();
        }


        //Getting Data By Id
        public async Task<Employee?> GetEmployeeAsync(Guid id)
        {
            return await _appDbContext.Employees
                                      .Include(e => e.Qualifications)
                                      .FirstOrDefaultAsync(e => e.GuidId == id);
        }


        //Update Image

        public async Task<(bool Success, string ImageUrl)> UpdateEmployeePhotoAsync(Guid id, IFormFile imageFile)
        {
            var employee = await _appDbContext.Employees.FirstOrDefaultAsync(e => e.GuidId == id);
            if (employee == null)
            {
                return (false, null);
            }

            var uploadsFolder = Path.Combine(_environment.WebRootPath, "Upload");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
            var filePath = Path.Combine(uploadsFolder, fileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(fileStream);
            }

            // Create the local link
            var localLink = Path.Combine("Upload", fileName).Replace("\\", "/");

            // Construct the URL that will be accessible from the client
            var imageUrl = $"/Upload/{fileName}";

            employee.ImageUrl = imageUrl;
            _appDbContext.Employees.Update(employee);
            await _appDbContext.SaveChangesAsync();

            return (true, imageUrl);
        }

        //Create Data

        public async Task<EmployeeDto> CreateEmployeeAsync(Employee employee, IFormFile imageFile, [FromForm] List<Qualification> qualifications)
        {
            // Handle image upload
            if (imageFile != null && imageFile.Length > 0)
            {
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "Upload");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                var filePath = Path.Combine(uploadsFolder, fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }
                // Create the local link
                var localLink = Path.Combine("/Upload", fileName).Replace("\\", "/");
                var localUrl = $"{_environment.WebRootFileProvider.GetFileInfo("/").PhysicalPath}{localLink}";
                employee.ImageUrl = localUrl;
            }

            // Add qualifications to the employee
            employee.Qualifications = qualifications;
            foreach (var qualification in qualifications)
            {
                qualification.EmployeeGuidId = employee.GuidId;
            }

            // Add employee to the database
            _appDbContext.Employees.Add(employee);
            await _appDbContext.SaveChangesAsync();

            // Map to DTO and return
            var getUserDto = _mapper.Map<EmployeeDto>(employee);
            return getUserDto;
        }

         //Update  Data

        public async Task<bool> UpdateEmployeeAsync(Guid id, Employee updatedEmployee)
        {
            var existingEmployee = await _appDbContext.Employees
                                                      .Include(e => e.Qualifications)
                                                      .FirstOrDefaultAsync(e => e.GuidId == id);
            if (existingEmployee == null)
                return false;

            _appDbContext.Entry(existingEmployee).CurrentValues.SetValues(updatedEmployee);

            foreach (var qualification in updatedEmployee.Qualifications)
            {
                var existingQualification = existingEmployee.Qualifications
                                                             .FirstOrDefault(q => q.Id == qualification.Id);

                if (existingQualification != null)
                {
                    _appDbContext.Entry(existingQualification).CurrentValues.SetValues(qualification);
                }
                else
                {
                    existingEmployee.Qualifications.Add(qualification);
                }
            }

            await _appDbContext.SaveChangesAsync();
            return true;
        }


        //Delete Data
        public async Task<bool> DeleteEmployeeAsync(Guid id)
        {
            var employee = await _appDbContext.Employees
                                              .Include(e => e.Qualifications)
                                              .FirstOrDefaultAsync(e => e.GuidId == id);
            if (employee == null)
                return false;

            _appDbContext.Employees.Remove(employee);
            await _appDbContext.SaveChangesAsync();
            return true;
        }



        //public async Task<List<Employee>> GetEmployeesAsync()
        //{
        //    return await _appDbContext.Employees
        //                               .Include(e => e.Qualifications)
        //                               .ToListAsync();
        //}

        //public async Task<Employee?> GetEmployeeAsync(Guid id)
        //{
        //    return await _appDbContext.Employees
        //                              .Include(e => e.Qualifications)
        //                              .FirstOrDefaultAsync(e => e.GuidId == id);
        //}


        //public async Task AddUserAsync(User user)
        //{
        //    // Add code to save user to database
        //    _appDbContext.Users.Add(user); // Assuming you have a DbSet<User> Users in your DbContext
        //    await _appDbContext.SaveChangesAsync();
        //}

        //public async Task<User> GetUserByUsernameAsync(string username)
        //{
        //    // Retrieve user from database
        //    return await _appDbContext.Users.FirstOrDefaultAsync(u => u.Username == username);
        //}


    }
}
