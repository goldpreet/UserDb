﻿namespace crud_dotnet_api.Data
{
    public class DbContextoptions
    {
    }
}