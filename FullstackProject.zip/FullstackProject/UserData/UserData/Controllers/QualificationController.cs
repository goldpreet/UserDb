﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace UserData.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

  
    public class QualificationsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public QualificationsController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet("qualifications/{qualificationId}")]
        public async Task<ActionResult<Qualification>> GetQualificationById(Guid qualificationId)
        {
            var qualification = await _context.Qualifications.FindAsync(qualificationId);
            if (qualification == null)
            {
                return NotFound();
            }

            return Ok(qualification);
        }
        [HttpPost("{userId}/qualifications")]
        public async Task<ActionResult<Qualification>> PostQualification(Guid userId, QualificationDto qualificationDto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return NotFound();
            }

            var qualification = new Qualification
            {
                Id = Guid.NewGuid(),
                QualificationName = qualificationDto.QualificationName,
                Experience = qualificationDto.Experience,
                Institution = qualificationDto.Institution,
                UserId = userId
            };

            _context.Qualifications.Add(qualification);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetQualificationById), new { qualificationId = qualification.Id }, qualification);
        }

        [HttpPut("qualifications/{qualificationId}")]
        public async Task<IActionResult> PutQualification(Guid qualificationId, QualificationDto qualificationDto)
        {
            var qualification = await _context.Qualifications.FindAsync(qualificationId);
            if (qualification == null)
            {
                return NotFound();
            }

            qualification.QualificationName = qualificationDto.QualificationName;
            qualification.Experience = qualificationDto.Experience;
            qualification.Institution = qualificationDto.Institution;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("qualifications/{qualificationId}")]
        public async Task<IActionResult> DeleteQualification(Guid qualificationId)
        {
            var qualification = await _context.Qualifications.FindAsync(qualificationId);
            if (qualification == null)
            {
                return NotFound();
            }

            _context.Qualifications.Remove(qualification);
            await _context.SaveChangesAsync();

            return NoContent();
        }


    }

}
