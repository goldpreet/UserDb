﻿namespace UserData
{
    // QualificationDto.cs
    public class QualificationDto
    {
        public string QualificationName { get; set; }
        public int Experience { get; set; }
        public string Institution { get; set; }
    }
}
