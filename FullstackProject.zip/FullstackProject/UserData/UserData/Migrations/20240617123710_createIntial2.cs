﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UserData.Migrations
{
    public partial class createIntial2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
