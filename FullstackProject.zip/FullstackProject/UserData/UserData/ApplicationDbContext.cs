﻿
    using Microsoft.EntityFrameworkCore;

    namespace UserData
    {
        // ApplicationDbContext.cs
        public class ApplicationDbContext : DbContext
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
            {
            }

            public DbSet<User> Users { get; set; }
            public DbSet<Qualification> Qualifications { get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.Entity<Qualification>()
                    .HasOne(q => q.User)
                    .WithMany(u => u.Qualifications)
                    .HasForeignKey(q => q.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            }
        }

    }


