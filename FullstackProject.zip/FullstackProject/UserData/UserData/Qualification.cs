﻿namespace UserData
{
    public class Qualification
    {
        public Guid Id { get; set; }
        public string QualificationName { get; set; }
        public int Experience { get; set; }
        public string Institution { get; set; }

        public Guid UserId { get; set; }
        public User User { get; set; }
    }
}
