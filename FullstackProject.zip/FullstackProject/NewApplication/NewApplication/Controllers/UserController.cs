﻿using DotNetAngular2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewApplication.Models;
using NewApplication.Services;

namespace NewApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public async Task<IActionResult> GetPersons()
        {
            var persons = await _userService.GetPersons();
            return Ok(persons);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPerson(Guid id)
        {
            var person = await _userService.GetPerson(id);
            if (person == null)
            {
                return NotFound();
            }

            return Ok(person);
        }

        [HttpPost]
        public async Task<IActionResult> PostPersons([FromBody] List<Person> persons)
        {
            if (persons == null || !persons.Any())
            {
                return BadRequest("Person list is empty");
            }

            var addedPersons = await _userService.AddPersons(persons);
            return Ok(addedPersons);
        }



        [HttpPut("{guidId}")]
        public async Task<ActionResult> UpdateEmployee(Guid guidId, [FromBody] Person model)
        {
            await _userService.UpdateEmployee(guidId, model);
            return Ok();
        }
        //[HttpPut("{id}/qualifications")]
        //public async Task<IActionResult> AddQualifications(Guid id, [FromBody] List<Qualification> qualifications)
        //{
        //    var newQualifications = await _userService.AddQualifications(id, qualifications);
        //    if (newQualifications == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(newQualifications);
        //}
    }
}





