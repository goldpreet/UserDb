﻿using NewApplication.Models;

namespace NewApplication.Services
{
    public interface IUserService
    {
        Task<List<Person>> GetPersons();
        Task<Person> GetPerson(Guid id);
        Task<List<Person>> AddPersons(List<Person> persons);
        Task UpdateEmployee(Guid guidId, Person updatedEmployee);
        // Task<Person> UpdateUserAndAddQualification(Guid id, Person person, List<Qualification> qualifications);
        //   Task UpdateUserAndAddQualification(Guid id, ICollection<Qualification> qualifications);

        // Task<List<Qualification>> AddOrUpdateQualifications(Guid id, List<Qualification> qualifications);

        //correct  Task<List<Qualification>> AddQualifications(Guid id, List<Qualification> qualifications);
    }
}
