﻿namespace NewApplication.Models
{
    public class PersonModel
    {
    }
}
