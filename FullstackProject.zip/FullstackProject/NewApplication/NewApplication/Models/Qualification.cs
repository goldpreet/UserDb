﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NewApplication.Models
{
    public class Qualification
    {
        [Key]
        public Guid ID { get; set; } 
        public string QualificationName { get; set; }
        [ForeignKey("PersonID")]
        public Guid PersonID { get; set; }

        //[Timestamp]
        //public byte[] RowVersion { get; set; }


        //  public Person? person { get; set;}
    }
}
