﻿using Microsoft.EntityFrameworkCore;
using NewApplication.Models;
using System;

namespace DotNetAngular2
{
    public class DataContext : DbContext
    {

        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Person> Users { get; set; }
        public DbSet<Qualification> UserQualifications { get; set; }




    }
}
