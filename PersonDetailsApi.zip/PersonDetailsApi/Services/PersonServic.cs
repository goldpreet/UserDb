﻿using System;
using System.Collections.Generic;
using System.Linq;
using PersonDetailsApi.Data;
using PersonDetailsApi.Models;
using Microsoft.EntityFrameworkCore;

namespace PersonDetailsApi.Services
{
    public class PersonService : IPersonService
    {
        private readonly DataContext _context;

        public PersonService(DataContext context)
        {
            _context = context;
        }

        public IEnumerable<Person> GetAllPersons()
        {
            return _context.Persons.ToList();
        }

        public Person GetPersonById(Guid guidId)
        {
            return _context.Persons.Find(guidId);
        }

        public void AddPerson(Person person)
        {
            person.guidId = Guid.NewGuid(); // Ensure a new Guid is generated
            _context.Persons.Add(person);
            _context.SaveChanges();
        }

        public void UpdatePerson(Person person)
        {
            var existingPerson = _context.Persons.Find(person.guidId);
            if (existingPerson != null)
            {
                _context.Entry(existingPerson).CurrentValues.SetValues(person);
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException("Person not found");
            }
        }

        public void DeletePerson(Guid guidId)
        {
            var person = _context.Persons.Find(guidId);
            if (person != null)
            {
                _context.Persons.Remove(person);
                _context.SaveChanges();
            }
            else
            {
                throw new KeyNotFoundException("Person not found");
            }
        }
    }
}
