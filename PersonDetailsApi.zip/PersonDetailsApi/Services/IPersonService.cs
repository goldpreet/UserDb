﻿using System;
using System.Collections.Generic;
using PersonDetailsApi.Models;

namespace PersonDetailsApi.Services
{
    public interface IPersonService
    {
        IEnumerable<Person> GetAllPersons();
        Person GetPersonById(Guid guidId);
        void AddPerson(Person person);
        void UpdatePerson(Person person);
        void DeletePerson(Guid guidId);
    }
}
