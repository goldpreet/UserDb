﻿using System.ComponentModel.DataAnnotations;

namespace PersonDetailsApi.Models
{
    public class Person
    {
        [Key]
        public  Guid guidId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public int Age { get; set; }

        [Required]
        public string Email { get; set; }
    }
}
