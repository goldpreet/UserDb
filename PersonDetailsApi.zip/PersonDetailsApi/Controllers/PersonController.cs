﻿using Microsoft.AspNetCore.Mvc;
using PersonDetailsApi.Models;
using PersonDetailsApi.Services;
using System;
using System.Collections.Generic;

namespace PersonDetailsApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeesController : ControllerBase
    {
        private readonly IPersonService _personService;

        public EmployeesController(IPersonService personService)
        {
            _personService = personService;
        }

        [HttpGet]
        public ActionResult<List<Person>> GetEmployees()
        {
            var employees = _personService.GetAllPersons();
            return Ok(employees);
        }

        [HttpGet("{guidId}")]
        public ActionResult<Person> GetEmployee(Guid guidId)
        {
            var employee = _personService.GetPersonById(guidId);
            if (employee == null)
            {
                return NotFound();
            }
            return Ok(employee);
        }

        [HttpPost]
        public ActionResult<Person> AddEmployee(Person person)
        {
            _personService.AddPerson(person);
            return CreatedAtAction(nameof(GetEmployee), new { guidId = person.guidId }, person);
        }

        [HttpPut("{guidId}")]
        public ActionResult UpdateEmployee(Guid guidId, Person person)
        {
            if (guidId != person.guidId)
            {
                return BadRequest();
            }

            var existingPerson = _personService.GetPersonById(guidId);
            if (existingPerson == null)
            {
                return NotFound();
            }

            _personService.UpdatePerson(person);
            return NoContent();
        }

        [HttpDelete("{guidId}")]
        public ActionResult DeleteEmployee(Guid guidId)
        {
            var existingPerson = _personService.GetPersonById(guidId);
            if (existingPerson == null)
            {
                return NotFound();
            }

            _personService.DeletePerson(guidId);
            return NoContent();
        }
    }
}
