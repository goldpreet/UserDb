﻿using Microsoft.EntityFrameworkCore;
using PersonDetailsApi.Models;

namespace PersonDetailsApi.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Person> Persons { get; set; }
    }
}
